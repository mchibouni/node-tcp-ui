(function() {
  console.log("'Allo from CoffeeScript!");

}).call(this);
