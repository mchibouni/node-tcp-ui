node-tcp-ui
===========

Proof of Concept Webapp to bind raw TCP Sockets through Socket.IO
