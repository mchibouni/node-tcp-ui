/*global define */
define([], function () {
    'use strict';

    return '\'Allo \'Allo!';
});